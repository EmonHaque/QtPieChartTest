#include "pieview.h"
#include "slice.h"
#include "PieSeries.h"
#include <QGraphicsScene>
#include <QRandomGenerator>
#include <QTextDocument>
#include <QTextCursor>

PieView::PieView(QWidget *parent) : QGraphicsView(parent){
    auto scene = new QGraphicsScene(this);
    scene->setSceneRect(0,0,200,200);
    setScene(scene);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ellipse = new QGraphicsEllipseItem();
    ellipse->setBrush(Qt::white);
    ellipse->setPen(Qt::NoPen);
    ellipse->setAcceptHoverEvents(true);
    ellipse->setFlag(QGraphicsItem::ItemIsSelectable);
    text = new QGraphicsTextItem(ellipse);
    text->setAcceptHoverEvents(false);
    addTextBlocks();
    connect(this, &PieView::mouseOver, this, &PieView::onMouseOver);
    connect(this, &PieView::mouseLeave, this, &PieView::onMouseLeave);
    connect(this, &PieView::backUp, this, &PieView::onBackUp);
}
void PieView::resizeEvent(QResizeEvent*){
    fitInView(scene()->itemsBoundingRect(), Qt::KeepAspectRatio);
    centerOn(0, 0);
}
void PieView::addTextBlocks(){
    auto cursor = QTextCursor(text->document());

    QTextBlockFormat blockFormat;
    QTextCharFormat charFormat;

    blockFormat.setAlignment(Qt::AlignHCenter);
    charFormat.setForeground(Qt::darkGreen);
    charFormat.setFontPointSize(16);
    cursor.setBlockFormat(blockFormat);
    cursor.setBlockCharFormat(charFormat);
    cursor.insertText("");

    charFormat.setForeground(Qt::red);
    charFormat.setFontPointSize(14);
    cursor.insertBlock(blockFormat, charFormat);
    cursor.insertText("");

    charFormat.setForeground(Qt::black);
    charFormat.setFontPointSize(12);
    cursor.insertBlock(blockFormat, charFormat);
    cursor.insertText("");
}
void PieView::onMouseOver(PieSeries &s){
    auto cursor = QTextCursor(text->document());
    cursor.movePosition(QTextCursor::EndOfBlock, QTextCursor::KeepAnchor);
    cursor.insertText(s.name);

    cursor.movePosition(QTextCursor::NextBlock);
    cursor.movePosition(QTextCursor::EndOfBlock, QTextCursor::KeepAnchor);
    cursor.insertText(QString::number(s.value));

    cursor.movePosition(QTextCursor::NextBlock);
    cursor.movePosition(QTextCursor::EndOfBlock, QTextCursor::KeepAnchor);
    cursor.insertText(QString::number(s.value / m_total * 100) + "%");

    text->setY(ellipse->boundingRect().center().y() - text->boundingRect().height()/2);
    if(!items().contains(ellipse)) scene()->addItem(ellipse);
}
void PieView::onMouseLeave(){
    if(!items().contains(ellipse)) return;
    // add someother mechanism instead of polling eg. hasSelection property
    foreach(auto item, items()){
        auto slice = dynamic_cast<Slice*>(item);
        if(!slice) continue;
        if(slice->isChecked()) return;;
    }
    scene()->removeItem(ellipse);
}
void PieView::onBackUp(Slice * current){
    // add someother mechanism instead of polling eg. hasSelection property
    foreach(auto item, items()){
        if(current == item) continue;
        auto slice = dynamic_cast<Slice*>(item);
        if(!slice) continue;
        if(!slice->isChecked()) continue;
        slice->integrate();
        slice->setChecked(false);
    }
}
void PieView::makePie(QVector<PieSeries>& series){
    if(items().contains(ellipse)) scene()->removeItem(ellipse);
    scene()->clear();
    m_total = 0;
    float startAngle = 0, spanAngle;
    for (int i = 0; i < series.size(); i++) m_total += series[i].value;
    QRandomGenerator rand;
    auto rect = sceneRect();
    for (int i = 0; i < series.size(); i++){
        spanAngle = series[i].value / m_total * 360;
        auto color = QColor::fromRgb(rand.global()->bounded(0,255), rand.global()->bounded(0,255), rand.global()->bounded(0,255));
        auto slice = new Slice(startAngle, spanAngle, color, rect, series[i]);
        scene()->addItem(slice);
        startAngle += spanAngle;
    }
    auto eRect = QRectF(QPoint(rect.center().x() - 75, rect.center().y() - 75), QSize(150,150));
    ellipse->setRect(eRect);
    text->setTextWidth(rect.width());
}
