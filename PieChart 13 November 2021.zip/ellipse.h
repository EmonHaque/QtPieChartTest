#ifndef ELLIPSE_H
#define ELLIPSE_H

#include <QGraphicsEllipseItem>
#include <PieSeries.h>
class PieView;

class Ellipse : public QGraphicsEllipseItem
{
public:
    Ellipse(PieView *view, QGraphicsItem *parent =0);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
protected:
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;
private:
    PieSeries m_series;
    PieView * m_view;
};

#endif // ELLIPSE_H
