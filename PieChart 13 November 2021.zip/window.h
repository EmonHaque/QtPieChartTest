#ifndef WINDOW_H
#define WINDOW_H

#include <QMainWindow>
class PieView;
class Window : public QWidget
{
    Q_OBJECT

    void oSelectionChanged(int index);
public:
    Window(QWidget *parent = nullptr);
    ~Window();

private:
    PieView * pie;
};
#endif // WINDOW_H
