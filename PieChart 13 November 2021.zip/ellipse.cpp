#include "ellipse.h"
#include "pieview.h"
#include <QPainter>
#include <QStyleOptionGraphicsItem>

Ellipse::Ellipse(PieView* view, QGraphicsItem * parent)
    : QGraphicsEllipseItem(parent), m_series(PieSeries(" ", 1)),  m_view(view){
    setBrush(Qt::white);
    setPen(Qt::NoPen);
    setAcceptHoverEvents(true);
    setFlag(QGraphicsItem::ItemIsSelectable);
   // m_series = PieSeries("e", 1);
}
void Ellipse::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
    QStyleOptionGraphicsItem op;
    op.initFrom(widget);
    if(option->state == QStyle::State_Selected)
        op.state = QStyle::State_None;
    QGraphicsEllipseItem::paint(painter, &op, widget);
}

void Ellipse::hoverEnterEvent(QGraphicsSceneHoverEvent*)
{

    emit m_view->mouseOver(m_series);
}

void Ellipse::hoverLeaveEvent(QGraphicsSceneHoverEvent*)
{
    emit m_view->mouseOver(m_series);
}
