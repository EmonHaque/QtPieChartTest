#include "slice.h"
#include <QPainter>
#include <QPainterPath>
#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include "pieview.h"

#define whats16 16
Slice::Slice(float start, float sweep, QColor color, QRectF rect, PieSeries& series, PieView * view, QGraphicsItem * parent)
    : QGraphicsItem(parent), m_start(start), m_sweep(sweep), m_color(color), m_series(series), m_view(view){
    m_isChecked = false;
    m_realColor = color;
    m_rect = rect;

    m_path = QPainterPath(QPointF(m_rect.width() / 2, m_rect.height() / 2));
    m_path.arcTo(m_rect, -m_start, -m_sweep);
    m_path.closeSubpath();
    dx = 10 * cos((m_start + m_sweep / 2) * M_PI / 180);
    dy = 10 * sin((m_start + m_sweep / 2) * M_PI / 180);

    int margin = 20;
    float dimension = m_rect.width() + 2 * margin;
    m_boundingRect = QRectF(-margin, -margin, dimension, dimension);
    setAcceptHoverEvents(true);
}
QRectF Slice::boundingRect() const { return m_boundingRect; }
QPainterPath Slice::shape() const { return m_path;}
void Slice::hoverEnterEvent(QGraphicsSceneHoverEvent*){
    emit m_view->mouseOver(m_series);
    if(m_isChecked) return;
    separete();
}
void Slice::hoverLeaveEvent(QGraphicsSceneHoverEvent*){
    emit m_view->mouseLeave();
    if(m_isChecked) return;
    integrate();
}
void Slice::mousePressEvent(QGraphicsSceneMouseEvent *e){
    if(e->button() != Qt::LeftButton) return;
    if(m_isChecked) m_isChecked = false;
    else{
        m_isChecked = true;
        emit m_view->backUp(this);
    }
}
void Slice::mouseReleaseEvent(QGraphicsSceneMouseEvent*){}
void Slice::paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*){
    painter->setRenderHint(QPainter::Antialiasing);
    painter->setPen(Qt::NoPen);
    painter->setBrush(m_color);
    painter->drawPie(m_rect, whats16 * -m_start, whats16 * -m_sweep);
}
void Slice::integrate(){
    m_color = m_realColor;
    moveBy(-dx, -dy);
    update();
}
void Slice::separete(){
    m_color = Qt::gray;
    moveBy(dx, dy);
    update();
}
bool Slice::isChecked(){ return m_isChecked; }
void Slice::setChecked(bool value){
    if(m_isChecked != value)
        m_isChecked = value;
}
