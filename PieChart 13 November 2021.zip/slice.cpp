#include "slice.h"
#include <QPainter>
#include <QPainterPath>
#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include "pieview.h"

#define whats16 16
Slice::Slice(float start, float sweep, QColor color, QRectF rect, PieSeries& series)
    : m_start(start), m_sweep(sweep), m_color(color), m_series(series){
    m_realColor = color;
    m_rect = rect;
    m_path = QPainterPath(QPointF(m_rect.width() / 2, m_rect.height() / 2));
    m_path.arcTo(m_rect, -m_start, -m_sweep);
    m_path.closeSubpath();
    dx = 10 * cos((m_start + m_sweep / 2) * M_PI / 180);
    dy = 10 * sin((m_start + m_sweep / 2) * M_PI / 180);
    float dimension = m_rect.width() + 2 * 20;
    m_boundingRect = QRectF(-20, -20, dimension, dimension);
    setAcceptHoverEvents(true);
    setFlag(QGraphicsItem::ItemIsSelectable);
}
QRectF Slice::boundingRect() const { return m_boundingRect; }
QPainterPath Slice::shape() const { return m_path;}
void Slice::hoverEnterEvent(QGraphicsSceneHoverEvent*){
    qDebug() << "hoverEnterEvent" << isSelected();
    if(isSelected()) return;
    m_color = Qt::gray;
    moveBy(dx, dy);
    auto view = static_cast<PieView*>(scene()->parent());
    emit view->mouseOver(m_series);
}
void Slice::hoverLeaveEvent(QGraphicsSceneHoverEvent*){
    qDebug() << "hoverLeaveEvent" << isSelected();
    if(isSelected()) return;
    m_color = m_realColor;
    moveBy(-dx, -dy);
    auto view = static_cast<PieView*>(scene()->parent());
    emit view->mouseLeave();
}
void Slice::mousePressEvent(QGraphicsSceneMouseEvent *e){
    if(e->button() != Qt::LeftButton) return;
    if(isSelected()) setSelected(false);
    else setSelected(true);
}
void Slice::mouseReleaseEvent(QGraphicsSceneMouseEvent*){}
void Slice::paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*){
    painter->setRenderHint(QPainter::Antialiasing);
    painter->setPen(Qt::NoPen);
    painter->setBrush(m_color);
    painter->drawPie(m_rect, whats16 * -m_start, whats16 * -m_sweep);
}
