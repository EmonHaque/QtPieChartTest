#ifndef SLICE_H
#define SLICE_H

#include <QGraphicsItem>
#include <QGraphicsItemAnimation>
#include "PieSeries.h"

class Slice : public QGraphicsItem
{
public:
    Slice(float start, float sweep, QColor color, QRectF rect, PieSeries &series, QGraphicsItem *parent = 0);
    QRectF boundingRect() const override;
    QPainterPath shape() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    inline PieSeries& label(){ return m_series; };
    void integrate();
    QString& name(){ return m_series.name;}
    void separete();
    bool isChecked();
    void setChecked(bool value);
protected:
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
private:
    float m_start, m_sweep, dx, dy;
    QRectF m_rect, m_boundingRect;
    QColor m_color, m_realColor;
    QPainterPath m_path;
    PieSeries m_series;
    bool m_isChecked;
};

#endif // SLICE_H
