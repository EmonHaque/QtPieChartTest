#include "window.h"
#include "pieview.h"
#include "PieSeries.h"
#include <QVBoxLayout>
#include <QComboBox>

Window::Window(QWidget *parent) : QWidget(parent){
    auto combo = new QComboBox(this);
    combo->addItems(QStringList() << "6" << "3");
    pie = new PieView(this);
    pie->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto lay = new QVBoxLayout(this);
    lay->setContentsMargins(0,0,0,0);
    lay->addWidget(combo);
    lay->addWidget(pie);
    setLayout(lay);
    connect(combo, &QComboBox::currentIndexChanged, this, &Window::oSelectionChanged);
    combo->setCurrentIndex(1);
}
void Window::oSelectionChanged(int index){
    QVector<PieSeries> series;
    if(index == 0){
        series.append(PieSeries("Series 1", 100));
        series.append(PieSeries("Series 2", 200));
        series.append(PieSeries("Series 3", 300));
        series.append(PieSeries("Series 4", 150));
        series.append(PieSeries("Series 5", 225));
        series.append(PieSeries("Series 6", 275));
    }
    else if(index == 1){
        series.append(PieSeries("Series 1", 200));
        series.append(PieSeries("Series 2", 900));
        series.append(PieSeries("Series 3", 150));
    }
    pie->makePie(series);
}

Window::~Window()
{
}

