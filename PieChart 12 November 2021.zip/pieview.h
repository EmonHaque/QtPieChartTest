#ifndef PIEVIEW_H
#define PIEVIEW_H

#include <QGraphicsView>
#include <QObject>
#include <QWidget>
#include <QVector>

class Slice;
class PieSeries;

class PieView : public QGraphicsView
{
    Q_OBJECT
public:
    PieView(QWidget *parent = 0);
    void makePie(QVector<PieSeries>&);
signals:
    void mouseOver(PieSeries&);
    void mouseLeave();
protected:
    void resizeEvent(QResizeEvent*) override;
private slots:
    void onMouseOver(PieSeries&);
    void onMouseLeave();
private:
    QGraphicsEllipseItem *ellipse;
    QGraphicsTextItem *text;
    float m_total;
};

#endif // PIEVIEW_H
