#include "pieview.h"
#include "slice.h"
#include "PieSeries.h"
#include <QGraphicsScene>
#include <QRandomGenerator>
#include <QTextDocument>
#include <QTextCursor>

PieView::PieView(QWidget *parent) : QGraphicsView(parent){
    auto scene = new QGraphicsScene(this);
    setScene(scene);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ellipse = new QGraphicsEllipseItem();

    ellipse->setBrush(Qt::white);
    ellipse->setPen(Qt::NoPen);
    ellipse->setAcceptHoverEvents(false);

    text = new QGraphicsTextItem(ellipse);
    text->setAcceptHoverEvents(false);
    connect(this, &PieView::mouseOver, this, &PieView::onMouseOver);
    connect(this, &PieView::mouseLeave, this, &PieView::onMouseLeave);
}
void PieView::resizeEvent(QResizeEvent*){
    fitInView(scene()->itemsBoundingRect(), Qt::KeepAspectRatio);
    centerOn(0, 0);
}
void PieView::onMouseOver(PieSeries &s){
    text->document()->clear();
    auto cursor = QTextCursor(text->document());
    QTextBlockFormat blockFormat;
    QTextCharFormat charFormat;

    blockFormat.setAlignment(Qt::AlignHCenter);
    charFormat.setForeground(Qt::darkGreen);
    charFormat.setFontPointSize(16);
    cursor.setBlockFormat(blockFormat);
    cursor.setBlockCharFormat(charFormat);
    cursor.insertText(s.name);

    charFormat.setForeground(Qt::red);
    charFormat.setFontPointSize(14);
    cursor.insertBlock(blockFormat, charFormat);
    cursor.insertText(QString::number(s.value));

    charFormat.setForeground(Qt::black);
    charFormat.setFontPointSize(12);
    cursor.insertBlock(blockFormat, charFormat);
    cursor.insertText(QString::number(s.value / m_total * 100) + "%");

    text->setY(ellipse->boundingRect().center().y() - text->boundingRect().height()/2);
    scene()->addItem(ellipse);
}
void PieView::onMouseLeave(){ scene()->removeItem(ellipse); }
void PieView::makePie(QVector<PieSeries>& series){
    scene()->clear();
    m_total = 0;
    float startAngle = 0, spanAngle;
    for (int i = 0; i < series.size(); i++) m_total += series[i].value;
    QRandomGenerator rand;
    auto rect = QRectF(0,0, 200,200);
    for (int i = 0; i < series.size(); i++){
        spanAngle = series[i].value / m_total * 360;
        auto color = QColor::fromRgb(rand.global()->bounded(0,255), rand.global()->bounded(0,255), rand.global()->bounded(0,255));
        auto slice = new Slice(startAngle, spanAngle, color, rect, series[i]);
        scene()->addItem(slice);
        startAngle += spanAngle;
    }
    auto eRect = QRectF(QPoint(sceneRect().center().x() - 75, sceneRect().center().y() - 75), QSize(150,150));
    ellipse->setRect(eRect);
    text->setTextWidth(rect.width());
}
