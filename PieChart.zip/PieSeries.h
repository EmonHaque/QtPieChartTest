#ifndef PIESERIES_H
#define PIESERIES_H
#include <QString>

struct PieSeries{
    QString name;
    float value;
    PieSeries(QString name, float value){
        this->name = name;
        this->value = value;
    }
};

#endif // PIESERIES_H
